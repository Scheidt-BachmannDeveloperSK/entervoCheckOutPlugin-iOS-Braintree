//
//  entervoCheckoutPluginBraintree.h
//  entervoCheckoutPluginBraintree
//
//  Created by Developer on 28.02.18.
//  Copyright © 2018 Scheidt & Bachmann. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for entervoCheckoutPluginBraintree.
FOUNDATION_EXPORT double entervoCheckoutPluginBraintreeVersionNumber;

//! Project version string for entervoCheckoutPluginBraintree.
FOUNDATION_EXPORT const unsigned char entervoCheckoutPluginBraintreeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <entervoCheckoutPluginBraintree/PublicHeader.h>


